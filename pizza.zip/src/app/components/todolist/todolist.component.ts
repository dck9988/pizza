import { Component, OnInit } from '@angular/core';
//import { StorageService } from '../../services/storage.service';
//import pizzaData from './pizza.json';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.scss']
})

// interface Pizza {
//   topname: String;
//   price: Number
// }

export class TodolistComponent  implements OnInit  {

  //pizzas: Pizza[] = pizzaData;
  public keyword:string | undefined;

  //public todolist:any[]=[];
  public todolist:any[]=[
    {
      "title": "Tomatoes",
      "price": 1,
      "status": 0
    },
    {
      "title": "Onions",
      "price": 0.5,      
      "status": 0
    },
    {
      "title": "Bell pepper",
      "price": 1,     
      "status": 0
    } ,
    {
      "title": "Mushrooms",
      "price": 2,     
      "status": 0
    }  
  ];

  public topingList:any[]=["tops","onioins"];
  public priceList:number[] = [11, 22, 31, 44];
  public sumList:number[] = [10, 22, 33, 44];

  public billAmount: number = 0;
  public nKey: number = 0;


  constructor() { }

  ngOnInit() {
  }

  doCalculate(key:any){
    if(this.todolist[key].status==0){
      this.todolist[key].status=1;
    }else{
      this.todolist[key].status=0;
    }

    this.billAmount = 0;
    this.nKey = key;

    for(var i=0; i<this.todolist.length; i++){
      if(this.todolist[i].status==1){
        this.billAmount = this.billAmount + this.todolist[i].price;
      } 
    }
    if(this.billAmount>0){
      this.billAmount = this.billAmount + 5;
    } 
    

  }
  //如果数组里面有keyword返回true  否则返回false
  todolistHasKeyword(todolist:any,keyword:any){
    //异步  会存在问题
    // todolist.forEach(value => {

    //   if(value.title==keyword){

    //       return true;
    //   } 
    // });

    

    // if(!keyword) return false;

    // for(var i=0;i<this.todolist.length;i++){
    //   if(this.todolist[i].status==1){

    //       return true;
    //   } 
    // }
    // return false;

  }


}
